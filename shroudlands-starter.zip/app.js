// Placeholder app.js for future expansion (WASM glue goes here)
// When you introduce a real engine or WASM module, you will:
// 1) fetch('game.wasm')
// 2) instantiate with WebAssembly.instantiateStreaming
// 3) bootstrap WebGL and input handlers
console.info('Shroudlands Starter: app.js ready');